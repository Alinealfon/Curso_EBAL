library(png)

aa <- dev.list()
if (length(aa) != 0) {
  dev.off(dev.list()["RStudioGD"])
}

old_path <- getwd()

lesson_dir <- file.path(path.package("swirl"), "Courses",
                        "EBAL", "Licao_6")

setwd(lesson_dir)

img <- readPNG("grafico_tab_nomes_S.png")
grid::grid.raster(img)

setwd(old_path)


rm(img)
rm(lesson_dir)
rm(aa)
rm(old_path)