library(png)

aa2 <- dev.list()
if (length(aa2) != 0) {
  dev.off(dev.list()["RStudioGD"])
}

data_path2 <- file.path("/Users/alinefonseca/Desktop/Curso Swirl/Estatística_básica_aplicada_à_linguística/Lição_1/desvio_padrao.png")

img2 <- readPNG(data_path2)

grid::grid.raster(img2)

rm(data_path2)
rm(img2)
