library(png)

aa3 <- dev.list()
if (length(aa3) != 0) {
  dev.off(dev.list()["RStudioGD"])
}

data_path3 <- file.path("/Users/alinefonseca/Desktop/Curso Swirl/Estatística_básica_aplicada_à_linguística/Lição_2/boxplot.png")

img3 <- readPNG(data_path3)

grid::grid.raster(img3)

rm(data_path3)
rm(img3)



