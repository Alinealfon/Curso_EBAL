library(png)

aa3 <- dev.list()
if (length(aa3) != 0) {
  dev.off(dev.list()["RStudioGD"])
}

lesson_dir3 <- file.path(path.package("swirl"), "Courses",
                        "Estatística básica aplicada à Linguística", "Lição 2")
data_path3 <- file.path(lesson_dir3, "boxplot.png")

img3 <- readPNG(data_path3)

grid::grid.raster(img3)

rm(data_path3)
rm(img3)

