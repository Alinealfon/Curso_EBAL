

library(png)
boxplot <- system.file("img", "boxplot.png", package="png")  # or your own file
img <- readPNG(boxplot)
grid::grid.raster(img)

